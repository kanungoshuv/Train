const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const LectureProgressSchema = new Schema({
  lectureId: { type: String, required: true },
  timePlayed: { type: Number, default: 0 }, // seconds watched
  watched: { type: Boolean, default: false } // true if 90% or more is watched
});

// Define the schema for each section's progress
const SectionProgressSchema = new Schema({
  sectionId: { type: String, required: true },
  lectures: [LectureProgressSchema] // Array of lecture progress
});
const userCourseSchema = new Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref:'user',
    required: true,
  },
  course: {
    type: Schema.Types.ObjectId,
    ref:'course',
    required: true
  },
  purchaseDate:{
    type:Date,
    require:true,
},

progress: { type: Map, of: SectionProgressSchema },

overallProgress:{
    type:Number,
    require:true
}
});

// Index to ensure a user can't enroll in the same course more than once
userCourseSchema.index({ user: 1, course: 1 }, { unique: true });


module.exports = mongoose.model('userCourse', userCourseSchema);
