const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const courseSchema = new Schema({
  course_id: {
    type: String,
    required: true,
    unique: true
  },
  course_name: {
    type: String,
    required: true
  },
  price: {
    type: String,
    required: true
  },
  video_list: {
    type: Map,
    of: {
      name: String,
      duration:String,
      lectures: [
        {
          lecture: String,
          title: String,
          url: String,
          duration:String
        }
      ]
    }
  },
  course_description: {
    type: String,
    required: true
  },
  whats_included: {
    type: String,
    required: true
  },
  course_picture: {
    type: String,
    required: true
  },
  type:{
    type:String,
    required:true
  }

});

module.exports = mongoose.model('Course', courseSchema);
