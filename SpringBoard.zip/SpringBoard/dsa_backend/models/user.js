const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
  firstName: {
    type: String,
    required: true,
    unique: false
  },
  lastName: {
    type: String,
    required: true,
    unique: false
  },
  email: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: function() {
      return !this.googleId;
    }
  },
  googleId: {
    type: String,
    unique: true,
    sparse: true 
  },
  profession: {
    type: String,
    required: true,
    
  },
  isVerified:{
    type:Boolean,
    required:true
  },
  token :{
    type: String,
  },

  courses: [{ type: Schema.Types.ObjectId, ref: 'userCourse' }] 

});




userSchema.statics.findByCriteria = async function (criteria) {
  const User = this;
  try {
    console.log('criteria findByCriteria',criteria)
    const data = await User.findOne(criteria).exec();
    console.log('data in findbycreteria',data)
    return data;
  } catch (error) {
    throw error;
  }
};



userSchema.statics.findActiveByCriteria = async function (criteria) {
  const User = this;
  try {
    console.log('criteria findActiveByCriteria',criteria)
    const data = await User.findOne(criteria).exec();
    console.log('data in findActiveByCriteria',data)
    return data;
  } catch (error) {
    throw error;
  }
};


userSchema.statics.findOrCreate = async function (condition, doc) {
  const User = this;
  try {
    let user = await User.findOne(condition);
    if (!user) {
      user = await User.create(doc);
    }
    return user;
  } catch (error) {
    throw error;
  }
};



module.exports = mongoose.model('User', userSchema);