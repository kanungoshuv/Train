const bcrypt = require('bcrypt');
const User = require('../../models/user');
const generateOTP = require('../../utils/generateOTP')
const Course = require('../../models/course');
const Messages = require('../../config/Messages')
const signupService = require('../../services/signupService')

module.exports.signUpController = async (req, res) => {
        console.log('authRoutes.req',Messages.serverMessage.firstName)
        try {
            console.log('in try')
           
          const { firstName, lastName, email, password, confirmPassword, profession,isVerified } = req.body;
          console.log('firstName',firstName)
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          const firstNameRegex = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
          const lastNameRegex = /^[A-Za-z]+$/;
         // const passwordRegex=/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]$/;
          const validEmail = emailRegex.test(email);
          const validFirstName = firstNameRegex.test(firstName);
          const validLastName = lastNameRegex.test(lastName);
          //const validPassword = passwordRegex.test(password);
          console.log('before array',profession)
         
          let errorArray = [
            { field: 'firstNameError', message: '' },
            { field: 'lastNameError', message: '' },
            { field: 'emailError', message: '' },
            { field: 'passwordError', message: '' },
            { field: 'confirmPasswordError', message: '' },
            { field: 'professionError', message: '' }
          ];
          console.log('errorArray',errorArray)
          console.log('errorArrat.firstName',errorArray.firstNameError)
          if (!firstName || firstName==undefined)  {
            errorArray[0].message=Messages.serverMessage.firstName;
            
            console.log('errorArray.firstNameError',errorArray.firstNameError)
          }else if(!validFirstName){
            console.log('errorArray.validFirstName',errorArray.firstNameError)
            errorArray[0].message=Messages.serverMessage.firstNameNotValid;
            
          }else if(firstName.length >50){
            console.log('errorArray.length',errorArray.firstNameError)
            errorArray[0].message=serverMessage.firstNameLengthError;
            
          }
      
          if (!lastName) {
            errorArray[1].message= Messages.serverMessage.lastName;
          }else if(!validLastName){
            errorArray[1].message= Messages.serverMessage.lastNameNotValid 

          }else if(lastName.length >50){
            errorArray[1].message=Messages.serverMessage.lastNameLengthError
          }
          if (!validEmail || !email) {
            errorArray[2].message=Messages.serverMessage.emailNotValid
          }
          
          // if(!validPassword){
          //   errorArray[3].message=Messages.serverMessage.passwordNotValid

          // }
          if (password !== confirmPassword) {
            errorArray[4].message= Messages.serverMessage.passwordNotMatch;
          }
          if(profession ===undefined){
            errorArray[5].message= Messages.serverMessage.passwordNotMatch;
          }
          console.log('errorArray after',errorArray)
          if(errorArray[0].message!=='' || errorArray[1].message!==''|| errorArray[2].message!==''||errorArray[3].message!=='' || errorArray[4].message!==''||errorArray[5].message!==''){
           console.log('in if',errorArray)
            return res.status(400).json({ response: Messages.serverMessage.signUpFail, error: errorArray })

          }else{
            console.log('after all check')
            try {
              const registrationData = req.body;
              registrationData.password= await bcrypt.hash(password, 10);
              
             
          
              const newUser = await signupService.registration(registrationData);
              console.log('newuser........',newUser.userPresent)
              if (newUser.userPresent === 'Already Present') {
                res.send({ status: 300, message: 'Email already Present',success:false });
              }else if(newUser.isVerified == true){
                console.log('sign up success')
                res.send({ status: 200, message: 'Sign in Successfull',success:true });
              }else{
                res.send({ status: 200, message: Messages.serverMessage.signUpSuccess,success:true });
              }
             
            } catch (err) {
              console.log('err', err);
             
                res.send({ status: 300, message: sails.config.serverMessage.serverError });
              
            }
            // signupService.registration(registrationData, (err) => {
            //   console.log('registrationData in controller', registrationData);
            //   if (err) {
            //     console.log('err', err);
            //     if (err === 'Already Present') {
            //       res.send({ status: 300, message: sails.config.serverMessage.emailAlreadyPresent });
            //     } else {
            //       res.send({ status: 300, message: sails.config.serverMessage.serverError });
            //     }
            //   } 
              
            //   else {
            //     res.send({ status: 200, message:  Messages.serverMessage.signUpSuccess });
            //   }
            // });
            }
          
        } catch (err) {
          console.log('authRoutes.err',err)
          if (err.code === 11000) {
            res.status(400).json({ error: Messages.serverMessage.accountExists });
          } else {
            res.status(500).json({ error: Messages.serverMessage.error500 });
          }
        }
    }