const bcrypt = require('bcrypt');
const User = require('../../models/user');
const generateOTP = require('../../utils/generateOTP')
const Course = require('../../models/course');
const Messages = require('../../config/Messages')
const { generateToken } = require('../../utils/jwt');


  module.exports.signInController = async (req,res) => {
        console.log('AuthController.SignInUser',req.body)
        try {
            const { email, password } = req.body;
            
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const validEmail = emailRegex.test(email);
            
            if(validEmail){
            console.log('in if valid email',validEmail)
                const user = await User.findOne({ email });
                console.log('user',user)
                if (!user) {
                  return res.status(401).json({ response: Messages.serverMessage.signUpFail, error: Messages.serverMessage.invalidEmailOrPassword, success: false  });
                }
                const validPassword = await bcrypt.compare(password, user.password);
                if (!validPassword) {
                  return res.status(401).json({ response: Messages.serverMessage.signUpFail, error: Messages.serverMessage.invalidEmailOrPassword, success: false });
                }
                if(user.isVerified===false){
                  return res.status(401).json({ response: Messages.serverMessage.signUpFail, error: 'User not verified. Check your email and confirm your account to sign in.', success: false });
                }
                console.log('valid passowrd',validPassword)
                const token = generateToken(user._id);
                console.log('token generated',token)
                const updatedUser = await User.findOneAndUpdate(
                  { email: email },
                  { $set: { token: token } },
                  { new: true } 
                );
                
                res.status(200).json({ response: Messages.serverMessage.signInSuccess, jwt_token: token, success: true,user:updatedUser });
              }
            else{
              return res.status(401).json({ response: Messages.serverMessage.signInFail , error: Messages.serverMessage.emailNotValid, success: false });}
          } catch (err) {
            res.status(500).json({ error: Messages.serverMessage.error500});
          }
        
    }