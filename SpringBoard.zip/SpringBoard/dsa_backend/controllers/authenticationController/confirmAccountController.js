const bcrypt = require('bcrypt');
const User = require('../../models/user');

const Messages = require('../../config/Messages')


module.exports.confirmAccountController = async (req,res) => {
  const {id} = req.body;
  console.log('req.body',id);
  try {
    const user = await User.findById(id);
    console.log('user.......',user)
    if(user){
        if(user.isVerified===true){
          return res.status(200).json({ message: 'Account is already verified!', success: true});
          
        }else{
        const user = await User.findByIdAndUpdate(
            id, 
            { isVerified: true }, 
            
            );
            console.log('user',user)
            return res.status(200).json({ message: 'Account successfully verified!', success: true});
        }
    }
   

    if (!user) {
      return res.status(404).json({ message: 'User not found', success: false});
    
    }
    
  } catch (error) {
    return res.status(500).json({ message: 'Error verifying account', success: false});
  }
 

  
}
 

    