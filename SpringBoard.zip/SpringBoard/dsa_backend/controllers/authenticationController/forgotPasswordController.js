const bcrypt = require('bcrypt');
const User = require('../../models/user');
const generateOTP = require('../../utils/generateOTP')
const sendOTP = require('../../utils/sendOTP');
const Course = require('../../models/course');
const Messages = require('../../config/Messages')
const jwt = require('jsonwebtoken');


module.exports.confirmOTPController = async (req,res) => {
  const {email,otp,tempToken} = req.body;
  console.log('req.body',email);
  console.log('req.body otp',otp)
  console.log('req.body token',tempToken)
  try{
    const decoded = jwt.verify(tempToken, 'resetPasswordSecret');
    console.log('decoded',decoded)
    const user = await User.findOne({ email: decoded.email });
    if (!user) {
      return res.status(400).send('User does not exist');
    }
  
  const timeElapsed = Date.now() - decoded.otpCreatedAt;

  if (timeElapsed > 60000) { 
    return res.status(400).json({ response: 'OPT has Expired ', error: 'OPT Failed', success: false});
  }
  if(otp===decoded.otp && email===decoded.email){
    return res.status(200).json({ message: 'Successfully Verified. Please input your new password.',success: true,otpConfirm:true });
  }  
  else {
    return res.status(200).json({ message: 'OTP is invalid',success: false });
   
  }   
  }catch (err) {
    return res.status(400).send('OTP expired');
  }
    
}
  module.exports.changePasswordController = async (req,res) => {
        const {email, currentPassword, newPassword, confirmNewPassword} = req.body;
        const passwordRegex=/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
         
          const validPassword = passwordRegex.test(newPassword);
          if (!currentPassword || !newPassword || !email || !confirmNewPassword) {
            return res.status(400).json({ message: Messages.serverMessage.allRequiredFields });
          }
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
         
          const validEmail = emailRegex.test(email);
          if (!validEmail) {
            
            return res.status(400).json({ response: Messages.serverMessage.signUpFail, error: Messages.serverMessage.emailNotValid });
          }
          if(!validPassword){
            return res.status(400).json({ response: Messages.serverMessage.signUpFail, error: Messages.serverMessage.passwordNotValid });
          }

          if (newPassword !== confirmNewPassword) {
            return res.status(400).json({ response: Messages.serverMessage.signUpFail, error: Messages.serverMessage.passwordNotMatch });
          }
       
        try{
          const user = await User.findOne({email});
          const isMatch =  bcrypt.compare(currentPassword, user.password);
          if(!isMatch){
            return res.status(401).json({ message: Messages.passwordIncorrect });
          }
    
          const hashedPassword = await bcrypt.hash(newPassword, 10);
          // const isSame = bcrypt.compare(currentPassword,hashedPassword);
          // if(isSame){
          //   return res.status(401).json({ message: 'New Password cannot be same as Current password!' });
          // }
          user.password = hashedPassword;
          await user.save();
    
          res.status(200).json({ message: Messages.serverMessage.passwordChangeSuccess });
    
        }catch (error) {
          console.error(error);
          res.status(500).json({ message: Messages.serverMessage.error500 });
        }
        
  }

  module.exports.forgotPasswordWithOtpController = async (req,res) => {
        console.log('authController.forgotPassword',req.body.email)
      
        try{
            const {email} = req.body;
            console.log('email',email)
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            const validEmail = emailRegex.test(email);
            if (!validEmail) {
              return res.status(400).json({ response: Messages.serverMessage.otpVerificationFailed, error: Messages.serverMessage.emailNotValid, success: false });
            }

            const user = await User.findOne({email});

            if(!user){
              res.send({ status: 300, response: Messages.serverMessage.userNotExists,  success: false, error: Messages.serverMessage.userNotExists });   
            }else{
              const otp = generateOTP();
              const token = jwt.sign({ email: user.email,otp:otp,otpCreatedAt:Date.now() }, 'resetPasswordSecret', { expiresIn: '15m' });
              console.log('token in forget opt send',token)
             
             
              sendOTP(email, otp);
              
              res.send({ status: 200, response: Messages.serverMessage.otpSuccess, token: token , success: true, error: "" });   
            }
            
          }catch(error){
            res.status(500).json({ error: Messages.serverMessage.error500 });
          }
  }

  module.exports.changePasswordAfterOtpVerifcationController = async (req,res) => {
        const {email, password, confirmPassword} = req.body;
        console.log('req.body in change password after otp verification',req.body)
        const passwordRegex=/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
         
          const validPassword = passwordRegex.test(password);
          if (!password || !confirmPassword) {
            return res.status(400).json({ message: Messages.serverMessage.allRequiredFields });
          }
          if(!validPassword){
            return res.status(400).json({ response: Messages.serverMessage.signUpFail, error: Messages.serverMessage.passwordNotValid });
          }

          if (password !== confirmPassword) {
            return res.status(400).json({ response: Messages.serverMessage.signUpFail, error: Messages.serverMessage.passwordNotMatch });
          }
       
        try{
          console.log('email before find',email)
          const user = await User.findOne({email});
            console.log('after find method',user)
          const hashedPassword = await bcrypt.hash(password, 10);
          console.log('hashedPassowrd',hashedPassword)
          // const isSame = bcrypt.compare(currentPassword,hashedPassword);
          // if(isSame){
          //   return res.status(401).json({ message: 'New Password cannot be same as Current password!' });
          // }
          console.log('user before paassord set',user)
          user.password = hashedPassword;
          await user.save();
    
          res.status(200).json({ message: Messages.serverMessage.passwordChangeSuccess ,success:true});
    
        }catch (error) {
          console.error(error);
          res.status(500).json({ message: Messages.serverMessage.error500 });
        }
        
  }
