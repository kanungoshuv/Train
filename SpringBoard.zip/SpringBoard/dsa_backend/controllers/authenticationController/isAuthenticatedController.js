const { verifyToken } = require('../../utils/jwt');
const jwt = require('jsonwebtoken');
const User = require('../../models/user');

  module.exports.isAuthenticatedController = async (req,res) => {
   

    const user = await User.findOne({ email :req.body.user_data});
    console.log('user',user)

    if(user.token ){
      return res.status(200).json({ status:'200',response: 'Authorized User', success: true, user:req.session.token });
    }else{
      return res.status(200).json({ status:'300', response: 'Unauthorized! Sign in to your account.' });  
    }
    
    // if(req.session.token == undefined){

    //   return res.status(200).json({ status:'300', response: 'Unauthorized! Sign in to your account.' });  
    // }else{
    //   return res.status(200).json({ status:'200',response: 'Authorized User', success: true, user:req.session.token });
    // }
    // const token = req.body.token;
    // console.log('token',token)
    // let blackList = [];
    // if(token===''){
    //     return res.status(401).json({ response: 'Unauthorized! Sign in to your account.' });  
    // }else if(token){
    //     const invalidateToken = (token) => {
    //         blackList.push(token)
    //         };
        
    //         const clearList = () => {
    //         myList = [];
    //         };
            
    //         const decodedToken = verifyToken(token);
    //         console.log('decodedToekn',decodedToken)
    //         if(decodedToken){
    //             return res.status(200).json({ response: 'Authorized User', success: true, user:decodedToken });
    //         }else if ( blackList.includes(token)) { 
    //           return res.status(401).json({ response: 'Unauthorized! Sign in to your account.'}); 
    //         }
    // }     
    }