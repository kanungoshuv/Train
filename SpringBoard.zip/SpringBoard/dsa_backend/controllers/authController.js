const bcrypt = require('bcrypt');
const User = require('../models/user');
const generateOTP = require('../utils/generateOTP')
const Course = require('../models/course');
const Messages = require('../config/Messages')
const { invalidateToken } = require('../middleware/authMiddleware');

module.exports = {

    async logout(req,res){
      console.log('courselistcontroller.....',req.user.userId)
      console.log('courselistcontroller.....token',req.body.token)
      // Destroy the session
      if (req.body.token){
        User.findByIdAndUpdate(req.user.userId, { $unset: { token: "" } });
      
          invalidateToken(req.body.token);
          return res.status(200).json({ status:'200',message: Messages.serverMessage.logoutSuccess })
      }else{
        return res.status(300).json({ sttaus:'300',message: 'You are not logged in ' })
      }
    },
    async CourseDetails(req,res){
        try {
            const course_name = req.query.course_name;
            
            
            if (!course_name) {
              return res.status(400).json({ error: 'Course name is required', success: false });
            }
      
            const course = await Course.findOne({ course_name });
            if (!course) {
              return res.status(404).json({ error: 'Course not found', success: false });
            }
            res.status(200).json({ response: "Course Detail Send Successful", details: course });
          }catch(error){
            console.error(error);
            res.status(500).json({ error: 'Internal Server Error' , success: false});
        }
    },



};