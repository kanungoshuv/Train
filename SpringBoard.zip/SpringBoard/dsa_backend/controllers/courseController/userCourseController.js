const { findMyCourseById} = require('../../services/userCourseService')
const Messages = require('../../config/Messages')


module.exports.myCourseController = async (req,res) => {
  console.log('user courselistcontroller session',req.user.userId)
    try{
      console.log('in try.............')
        let myCourses = await findMyCourseById(req.user.userId)
        console.log('mycourse',myCourses.length)
        res.status(200).json(myCourses);
    } catch (error) {
        res.status(404).json({ message:Messages.serverMessage.courseNotFound , error: error.message });
    }
  }

