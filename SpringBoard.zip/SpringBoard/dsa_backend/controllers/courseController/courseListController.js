const Course = require('../../models/course');
const { findOneCourse,findAllCourse,findAllCoursesPurchased } = require('../../services/courseService')
const Messages = require('../../config/Messages')



module.exports.courseListControllerWithoutLogin = async (req,res) => {
    try{
      console.log('in all......')
      let allCourses = await findAllCourse()
            const extractedDocs = allCourses.map(course => {
              const { video_list, ...courseWithoutVideoList } = course._doc;
              return courseWithoutVideoList;
          });
          console.log('extractedDocs',extractedDocs)
            res.status(200).json({ Course_list: extractedDocs, success: true });
          

        }catch(err){
          res.status(500).json({ error: Messages.serverMessage.error500,success: false});
        }
  },

module.exports.courseListController = async (req,res) => {
  console.log('courselistcontroller.....',req.user.userId)
    try{
      let purchasedCourses
        let allCourses = await findAllCourse()
        if(req.user.userId){
          console.log('in if if user id from session')
          purchasedCourses = await findAllCoursesPurchased(req.user.userId)
          console.log('purchasedCourses',purchasedCourses)
        if(purchasedCourses){
          const allcoursesStr = allCourses.map(course => {
            const plainCourse = course.toObject();
            return {
              ...plainCourse,
              _id: plainCourse._id.toString()
            };
          });
       
          const purchasedCoursesStr = purchasedCourses.map(purchase => {
            return {
              ...purchase.toObject(),
              _id: purchase._id.toString(),
              user: purchase.user.toString(),
              course: purchase.course.toString(),
              purchaseDate: purchase.purchaseDate.toISOString()
            };
          });
       
          const enrichedCourses = allcoursesStr.map(course => {
            
            const purchasedCourse = purchasedCoursesStr.find(purchase => purchase.course === course._id);
            if (purchasedCourse) {
              return {
                ...course,
                purchasedCourseDetails: purchasedCourse
              };
            }
            
            return course;
          });
        
            const coursesWithPurchasedDetails = [];
            const coursesWithoutPurchasedDetailsWithVideoList = [];

            enrichedCourses.forEach(course => {
              if (course.purchasedCourseDetails) {
                coursesWithPurchasedDetails.push(course);
              } else {
                coursesWithoutPurchasedDetailsWithVideoList.push(course);
                
              }
            });
            const coursesWithoutPurchasedDetails = coursesWithoutPurchasedDetailsWithVideoList.map(course => {
              const { video_list, ...courseWithoutVideoList } = course;
              return courseWithoutVideoList;
          });
            const combinedJson = {
              coursesWithPurchasedDetails,
              coursesWithoutPurchasedDetails
            };

          res.status(200).json({ Course_list: combinedJson, success: true });
          }
          }else{
            const extractedDocs = allCourses.map(course => {
              const { video_list, ...courseWithoutVideoList } = course._doc;
              return courseWithoutVideoList;
          });
            res.status(200).json({ Course_list: extractedDocs, success: true });
          }

        }catch(err){
          res.status(500).json({ error: Messages.serverMessage.error500,success: false});
        }
  },

module.exports.courseDetailsByIdController = async (req,res)=>{
  console.log('in courseDetailsByIdController',req.query.id)

  try {
    
      const course = await findOneCourse(req.query.id);
      res.status(200).json(course);
    
    
   
} catch (error) {
    res.status(404).json({ message:Messages.serverMessage.courseNotFound , error: error.message });
}
}

