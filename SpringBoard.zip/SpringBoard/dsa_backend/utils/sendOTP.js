const nodemailer = require('nodemailer');

function sendOTP(email,otp){
    const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: "miti8797@gmail.com",
      pass: "antc rymf swzk gwco"  
    }
  });
  var optText = `<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>OTP Confirmation</title>
      <style>
          /* CSS styles for email content */
          body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              background-color: #f5f5f5;
              color: #333333;
              margin: 0;
              padding: 0;
          }
          .container {
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
              border: 1px solid #ccc;
              border-radius: 8px;
              background-color: #ffffff;
          }
          h1, p {
              margin: 0;
              padding: 0;
          }
          h1 {
              font-size: 24px;
              color: #009688;
              margin-bottom: 10px;
          }
          p {
              font-size: 16px;
              color: #555555;
              margin-bottom: 16px;
          }
      </style>
  </head>
  <body>
      <div class="container">
          <h1>OTP Confirmation</h1>
          <p>Dear User,</p>
          <p>Your OTP for verification is: <strong>${otp}</strong></p>
          <p>Please use this OTP to complete your verification process.</p>
          <p>If you did not request this OTP, please ignore this email.</p>
          <p>Regards,<br>SpringBoard Incubators</p>
      </div>
  </body>
  </html>
  `
  const sendOTPEmail = {
    from: "miti8797@gmail.com", 
    to: email,
    subject: "OTP requested for Password Change",
    html: optText,
  };

  transporter.sendMail(sendOTPEmail, (error, info) => {
    if (error) {
      console.log(error);

    } else {
      console.log('OTP sent to customer: ' + info.response);

    }
  });

};
module.exports = sendOTP;