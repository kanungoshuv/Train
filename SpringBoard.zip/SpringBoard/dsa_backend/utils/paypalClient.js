const paypal = require('paypal-rest-sdk');
require('dotenv').config();

paypal.configure({
    'mode': "sandbox",
    'client_id': "Aet9X5fl85bQYNW6ot-ynO7xXs0ITnvXjI4ib9gBmli7aSxi9uMkQT_UJVOOJsX-Wkk3gmv1U_3qguIx",
    'client_secret': "ELkBPnVMr4PYVk9VidYuoKLaeUa3L12r1aCSCYn-3Hzje_IEZe5kugHKxQf9UHkfzSQvBi90zGcz0Sis"
});

module.exports = paypal;