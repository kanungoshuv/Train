const paypal = require('../utils/paypalClient');
const Course = require('../models/course');
require('dotenv').config();

const createPayment = async (req, res, next) => {
  console.log('req.user.userid from jwt',req.user.userId)
    const baseUrl = process.env.BACKEND_URL;
    const courseIds = req.body.course_ids;
    let totalPrice = 0;
    let items = [];
    const courseDetails = await Course.find({ course_id: { $in: courseIds } });
    courseDetails.forEach((course, index) => {
      totalPrice += Number(course.price);
      
      items.push({
        "name": course.title, // Assuming there's a title field for each course
        "sku": `00${index + 1}`, // Unique SKU for each item
        "price": course.price, // Price for each course
        "currency": "USD",
        "quantity": 1
      });
    });
    console.log('Total Price:', totalPrice);
    console.log('PayPal Items:', items);
    const courseIdsString = courseIds.join(',');
 
  const create_payment_json = {
    "intent": "sale",
    "payer": {
      "payment_method": "paypal"
    },
    "redirect_urls": {
      "return_url": `${baseUrl}/success?totalPrice=${totalPrice}&courseIds=${courseIdsString}&state=${req.user.userId}`,
      "cancel_url": `${baseUrl}/cancel`
    },
    "transactions": [{
      "item_list": {
        "items": items
      },
      "amount": {
        "currency": "USD",
        "total": totalPrice.toFixed(2)
      },
      "description": "Purchase of a course"
    }]
  };

  paypal.payment.create(create_payment_json, (error, payment) => {
    if (error) {
      console.error(error);
      res.status(500).json({ error: 'Payment creation failed' });
    } else {
      req.paymentId = payment.id;
      req.payment = payment;
    //   req.amount = req.body.amount;
      next();
    }
  });
};

const executePayment = async (req, res, next) => {
  console.log('in execute payment')
  const paymentId = req.query.paymentId;
  const payerId = req.query.PayerID;
  const price = req.query.totalPrice;
  console.log('amount = ', price);
  const execute_payment_json = {
    "payer_id": payerId,
    "transactions": [{
      "amount": {
        "currency": "USD",
        "total": price 
      }
    }]
  };

  paypal.payment.execute(paymentId, execute_payment_json, (error, payment) => {
    if (error) {
      console.error("error  ",  error.response);
      res.status(500).json({ error: 'Payment execution failed' });
    } else {
        
      req.payment = payment;
      next();
    }
  });
};

module.exports = { createPayment, executePayment };
