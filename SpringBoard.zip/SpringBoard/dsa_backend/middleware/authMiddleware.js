const { verifyToken } = require('../utils/jwt');
const jwt = require('jsonwebtoken');
const User = require('../models/user');

let blackList = [];

const invalidateToken = (token) => {
  console.log('in invalid token',token)
  blackList.push(token)
};

const clearList = () => {
  myList = [];
};

setTimeout(clearList, 3 * 60 * 60 * 1000); 

  const authenticateToken = async (req, res, next) => {
  console.log('in auth token................')
  const authHeader = req.headers['authorization'];

  // Token is typically in the format "Bearer <token>"
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Access denied, no token provided' });

  // Verify the token
  jwt.verify(token, process.env.JWT_SECRET_TOKEN, (err, user) => {
      if (err) return res.status(403).json({ message: 'Invalid or expired token' });
      console.log('user',user)
      req.user = user; // Set the user in request
      next(); // Move to the next middleware/route handler
  });
}
const requireAuth = async (req, res, next) => {
  console.log('mutoMiddleware..................',req.body)
  console.log('req.session........',req.session)
  try{
    const users = await User.find({ token: { $ne: null } })
    console.log('users',users);
    for (const user of users) {
      console.log('in for loop',user.token)
      try {
       
        // if (blackList.includes(token)) { 
        //   return res.status(401).json({ error: 'Unauthorized! Sign in to your account.' }); 
        // }
      // Verify if the token is expired
       const verfiedToken = jwt.verify(user.token, process.env.JWT_SECRET_TOKEN);
       console.log('verified token',verfiedToken)
       if(verfiedToken){ 
        console.log('user.token',user.token)
        req.session.token = user.token
        req.session.userId = verfiedToken.userId
       }
      } catch (err) {
        console.log('in catch')
        // Token is expired or invalid, remove it
        await User.findByIdAndUpdate(user._id, { $unset: { token: "" } });
        console.log(`Removed expired token for user ${user._id}`);
      }
    }
    next();
  }catch(error){
    console.log('in this catch')
    res.status(401).json({ error: 'Unauthorized! Sign in to your account.' });
  }
};

module.exports = { requireAuth ,invalidateToken,authenticateToken};