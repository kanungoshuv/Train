const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const authRoutes = require('./routes/authenticationRoutes/authRoutes');
const passport = require('passport');
const cookieParser = require('cookie-parser');
const AWS = require('aws-sdk');
const fs = require('fs');
const path = require('path');
require('dotenv').config();
const session = require('express-session');
const {requireAuth, invalidateToken} = require('./middleware/authMiddleware')
const Course = require('./models/course'); 
const cors = require('cors');
const MongoStore = require('connect-mongo');
const ffmpeg = require('fluent-ffmpeg');
const app = express();

console.log('process.env.MONGO_URL',process.env.MONGO_URL)
mongoose.connect(process.env.MONGO_URL, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
  })
  .catch((err) => {
    console.error('Error connecting to MongoDB', err);
  });

// mongoose.connect('mongodb://appuser:SpringBoard@172.31.16.66:27017/elpmdb', { useNewUrlParser: true, useUnifiedTopology: true })
//   .then(() => {
//     console.log('Connected to MongoDB');
//   })
//   .catch((err) => {
//     console.error('Error connecting to MongoDB', err);
//   });
app.set('trust proxy', 1); // trust first proxy

app.use(session({
  secret: 'DSASecret!!!',
  resave: false,
  saveUninitialized: true,
  name:'MyDsaApp',
  cookie: { 
    secure: false, // Set to true if using HTTPS
    httpOnly:true,
   // path:'/',
    sameSite:'none',
    maxAge: 24 * 60 * 60 * 1000, // 1 day
},
proxy: true 

}));



app.use(cookieParser());
app.use(passport.initialize());
app.use(passport,session())
app.use(cors({
  origin:  process.env.CORS_ORIGIN,
  credentials: true
}));



app.use(bodyParser.json());

AWS.config.update({ region: 'us-east-1' });
const s3 = new AWS.S3({
  accessKeyId: process.env.ACCESS_KEY_ID,
  secretAccessKey: process.env.SECRET_ACCESS_KEY
});

app.use(function(req, res, next) {
  res.setHeader('Access-Control-Allow-Origin', process.env.CORS_ORIGIN);
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Allow-Credentials', true);
  req.session.cookie.maxAge = 30 * 60 * 1000; 
  next();
});






app.use('/api', authRoutes);



  process.chdir(__dirname);

 const PORT = process.env.PORT || 3000;

app.listen(PORT,() => {
  console.log(`Server is running on port ${PORT}`);
});
const bucketName = process.env.BUCKET_NAME;
const cloudFrontDomainName = process.env.CLOUDFRONT_DOMAIN_NAME;
const bucketNameVideo = process.env.BUCKET_NAME_VIDEO;




const processAndUpdateVideos = async () => {
  try {
    const params = {
      Bucket: bucketNameVideo,
    };

    const data = await s3.listObjectsV2(params).promise();
    const urls = data.Contents.map(item => `https://${cloudFrontDomainName}/${item.Key}`);


    // Parse and organize video data
    const parseVideoUrl = (url) => {
      const parts = url.split('/');
      const fileName = parts.pop().split('_');
     
      return {
        course: fileName[0],
        section: fileName[1],
        lecture: fileName[3],
        sectionName:fileName[2],
        duration:fileName[5].replace('.mp4', ''),
       // title: fileName.slice(4).join('').replace('.mp4', '').replace(/([A-Z])/g, ' $1').trim()
       title:fileName[4].replace(/([A-Z])/g, ' $1').trim()
      };
    };

    const createVideoList = (urls) => {
      const videoList = {};
      let durationTotal ={duration :0,sectionName:'',courseName:''}
      urls.forEach((url) => {
       // getVideoDurationFromUrl(url);

        const { course, section, lecture, title,sectionName,duration } = parseVideoUrl(url);
       
        
        
        if (!videoList[course]) {
          videoList[course] = {};
        }

        if (!videoList[course][section]) {
          videoList[course][section] = {
            name: sectionName,
            duration:durationTotal.duration,
            lectures: []
          };
        }

        videoList[course][section].lectures.push({
          lecture,
          title,
          url,
          duration
        });
        videoList[course][section].duration += parseInt(duration);
      });
      
      return videoList;
    };

   
    const structuredVideoList = createVideoList(urls);
    
    // Update MongoDB documents
    for (const course in structuredVideoList) {
      await Course.updateOne(
        { imageName: course }, // Match the document by imageName
        { $set: { video_list: structuredVideoList[course] } }, // Replace the video_list field
        { new: true } // Option to return the updated document
      );
    }

    console.log('Documents updated successfully');
  } catch (err) {
    console.error('Error processing and updating videos:', err);
  } 
};




//image function
// const getPresignedUrl = async (key) => {
//   try {
//     const url = await s3.getSignedUrlPromise('getObject',{
//       Bucket:bucketName,
//       Key:key,
//      //Expires:345600
//     })
//     return url;
//   }catch(err){
//     console.error('Error generating presigned URL', err);
//     throw err;
//   }
// }


// //image function
// const listObjects = async () => {

//   try {
//     const data = await s3.listObjectsV2({ Bucket: bucketName }).promise();
//     return data.Contents.map(item => item.Key);
//   } catch (err) {
//     console.error('Error listing objects:', err);
//     return [];
//   }
// };

// //image function
// const generatePresignedUrls = async () => {
//   try {
//     const keys = await listObjects();
//     const presignedUrls = await Promise.all(keys.map(key => getPresignedUrl(key)));
//     return presignedUrls;
//   } catch (err) {
//     console.error('Error generating presigned URLs for multiple images', err);
//     throw err;
//   }
// };


// //image function
// const updateCoursesWithImageUrls = async (imageUrls) => {
//   try {
  
//     for (const imageUrl of imageUrls) {
//       const imageName = imageUrl.split('/').pop().split('?')[0]; 
//       await Course.findOneAndUpdate(
//         { imageName: imageName.split('.')[0] }, 
//         { course_picture: imageUrl },
//         { new: true }
//       );
//     }
//     console.log('Courses updated with image URLs');
//   } catch (err) {
//     console.error('Error updating courses with image URLs', err);
//   }
// };

// //image function
// const mainFunction = async () => {
//   try {
//     console.log('in main function')
//     const presignedUrls = await generatePresignedUrls();
//     await updateCoursesWithImageUrls(presignedUrls);
  
//   } catch (err) {
//     console.error('Error in main function', err);
//   }
// };

//mainFunction();
// storeVideoUrlsInCourses();
processAndUpdateVideos()