const express = require('express');
const router = express.Router();
const User = require('../../models/user');
const passport = require("passport");
const bcrypt = require('bcrypt');
const { OAuth2Client } = require('google-auth-library');
const client = new OAuth2Client();
const { generateToken } = require('../../utils/jwt');
const {requireAuth, invalidateToken,authenticateToken} = require('../../middleware/authMiddleware')
const jwt = require('jsonwebtoken');
const generateOTP = require('../../utils/generateOTP')
const Messages = require('../../config/Messages')

const Course = require('../../models/course');
const UserCourse = require('../../models/userCourse');
const authContoller = require('../../controllers/authController')
const { signInController } = require('../../controllers/authenticationController/signInController')
const {confirmAccountController} = require('../../controllers/authenticationController/confirmAccountController')
const { signUpController } = require('../../controllers/authenticationController/signUpController')
const {isAuthenticatedController} = require('../../controllers/authenticationController/isAuthenticatedController')
const {
  changePasswordController,
  forgotPasswordWithOtpController,
  changePasswordAfterOtpVerifcationController,
  confirmOTPController
} = require('../../controllers/authenticationController/forgotPasswordController')
const { courseListController,courseDetailsByIdController,courseListControllerWithoutLogin } = require('../../controllers/courseController/courseListController');
const {createPayment,executePayment} = require('../../middleware/paypalMiddleware')
const {myCourseController}=require('../../controllers/courseController/userCourseController')
// @desc            Customer Sign Up
// @base-route      POST /api/auth
// @route           POST /CustomerSignUp
// @return          User Detail
// @data-type       JSON
router.post('/isAuthenticated',isAuthenticatedController)
router.post('/signup', signUpController); 
router.post('/signin',signInController);
router.post('/confirmAccount',confirmAccountController)
router.post('/logout',authenticateToken,authContoller.logout);
router.post('/changePassword', changePasswordController);
router.post('/forgotPassword/sendOTP', forgotPasswordWithOtpController);
router.post('/changePasswordAfterOtpVerification', changePasswordAfterOtpVerifcationController)
// router.get('/courseList',courseListController);
 router.get('/courseAllList',courseListControllerWithoutLogin);


router.get('/courseList',authenticateToken, courseListController);

router.post('/confirmOtp',confirmOTPController);
router.get('/courseDetail', courseDetailsByIdController);
router.get('/myCourse',authenticateToken, myCourseController);
require('dotenv').config();

// router.post("/google", async (req, res) => {
//   const { credential, client_id } = req.body;
//   try {
//     const ticket = await client.verifyIdToken({
//     idToken: credential,
//     audience: client_id,
//   });
//   const payload = ticket.getPayload();
//   console.log('payload',payload)

//   const activeUser = await User.findActiveByCriteria({ email: payload.email, isVerified: true });
//     // if (activeUser) {
//     //   console.log('activeUser....................', activeUser);
//     //   //return callback('Already Present');
      
//     //   return ({userPresent:'Already Present'});
//     // }

//     // Check if user exists by criteria
//     const existingUser = await User.findByCriteria({ email: payload.email });
//     // console.log('existing User ......................... dcefce 4564.............',existingUser)
//     // if (existingUser) {
//     //   console.log('existingUser..................&%^%', existingUser);
//     //   console.log('User already present.');
//     //   return ({userPresent:'Already Present'});
     
//     // }
//     if(activeUser || existingUser){
//       console.log('in if................',)
//       let email = payload.email
//     const user = await User.findOne({ email });
//    console.log('user..',user)
//    const token = generateToken(user._id);
//    console.log('token generated',token)
//    const updatedUser = await User.findOneAndUpdate(
//      { email: email },
//      { $set: { token: token } },
//      { new: true } 
//    );
//    console.log('updated user',updatedUser)
//     if(updatedUser){
//       console.log('in if before sending to client')
//       res.status(200).json({ response: Messages.serverMessage.signInSuccess, jwt_token: updatedUser.token,success: true,user:updatedUser });
//     }
//     }
//   console.log('in if after')
//    if(!activeUser && !existingUser && payload.email_verified ===true){
//     let newUser;
//     console.log('in ifffff of second if')
//     const registrationData ={
//       firstName : payload.given_name,
//       lastName:payload.family_name,
//       email:payload.email,
//       profession:'student',
//       googleId:req.body.client_id,
//       isVerified:payload.email_verified
//     }
//     console.log('registration user second',registrationData)
//     newUser = await User.create(registrationData);
//     console.log('new user second',newUser)
//    }
//    const email = newUser.email
//    const user = await User.findOne({email });
//    console.log('user.. second',user)
//    const token = generateToken(user._id);
//    console.log('token generated second',token)
//    const updatedUser = await User.findOneAndUpdate(
//      { email: email },
//      { $set: { token: token } },
//      { new: true } 
//    );
//    console.log('updated user seconf',updatedUser)
//     if(updatedUser){
//       res.status(200).json({ response: Messages.serverMessage.signInSuccess, jwt_token: token,success: true,user:updatedUser });
//     }
   

//   } catch (err) {
//     res.status(400).json({ err });
//   }
// });

router.post("/google", async (req, res) => {
  const { credential, client_id } = req.body;

  try {
    // Verify Google token
    const ticket = await client.verifyIdToken({
      idToken: credential,
      audience: client_id,
    });
    const payload = ticket.getPayload();
    console.log('payload', payload);

    const activeUser = await User.findActiveByCriteria({ email: payload.email, isVerified: true });

    // If user is active or exists, update their token
    if (activeUser) {
      console.log('Active user found.');
      const token = generateToken(activeUser._id);
      const updatedUser = await User.findOneAndUpdate(
        { email: payload.email },
        { $set: { token } },
        { new: true }
      );

      if (updatedUser) {
        console.log('Updated user token');
        return res.status(200).json({ 
          response: Messages.serverMessage.signInSuccess, 
          jwt_token: updatedUser.token, 
          success: true, 
          user: updatedUser 
        });
      }
    }

    const existingUser = await User.findByCriteria({ email: payload.email });

    if (existingUser) {
      console.log('Existing user found.');
      const token = generateToken(existingUser._id);
      const updatedUser = await User.findOneAndUpdate(
        { email: payload.email },
        { $set: { token } },
        { new: true }
      );

      if (updatedUser) {
        console.log('Updated existing user token');
        return res.status(200).json({ 
          response: Messages.serverMessage.signInSuccess, 
          jwt_token: updatedUser.token, 
          success: true, 
          user: updatedUser 
        });
      }
    }

    // If user does not exist, create a new user
    if (!activeUser && !existingUser && payload.email_verified) {
      const registrationData = {
        firstName: payload.given_name,
        lastName: payload.family_name,
        email: payload.email,
        profession: 'student',
        googleId: req.body.client_id,
        isVerified: payload.email_verified
      };

      console.log('Registering new user:', registrationData);
      const newUser = await User.create(registrationData);

      const token = generateToken(newUser._id);
      const updatedUser = await User.findOneAndUpdate(
        { email: newUser.email },
        { $set: { token } },
        { new: true }
      );

      if (updatedUser) {
        console.log('New user created and updated');
        return res.status(200).json({ 
          response: Messages.serverMessage.signInSuccess, 
          jwt_token: token, 
          success: true, 
          user: updatedUser 
        });
      }
    }
  } catch (err) {
    console.error('Error:', err);
    return res.status(400).json({ error: err.message });
  }
});

router.post('/getProgress', authenticateToken, async (req, res) => {
  try {
    console.log('req.body',req.body.courseId)
    const course = req.body.courseId
    const userId = req.user.userId; // Assuming the user ID is stored in req.user after authentication
    const userCourse = await UserCourse.find({ user: userId ,course:course}); // Adjust as necessary
    console.log('userCourse',userCourse[0].progress)
    console.log('userCourse course',course)

    return res.status(200).json({ message: 'Progress fetched successfully', success: true,progress:userCourse});
    //const progressData = {};

    // userCourses.forEach(userCourse => {
    //   const { course, progress } = userCourse;
    //   progressData[course.name] = { // Assuming course has a 'name' property
    //     sectionId: course._id,
    //     lectures: [],
    //   };

    //   // Build the lectures array from the progress data
    //   for (const [sectionId, sectionProgress] of progress) {
    //     const lectures = sectionProgress.lectures.map(lecture => ({
    //       lectureId: lecture.lectureId,
    //       timePlayed: lecture.watchedSeconds, // Adjust this according to your schema
    //       watched: lecture.watched,
    //     }));

    //     progressData[course.name].lectures.push({
    //       sectionId,
    //       lectures,
    //     });
    //   }
    // });

    res.json(progressData);
  } catch (error) {
    console.error('Error fetching progress data:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

router.post('/saveProgress', async (req, res) => {
   console.log('in save progress',req.body)
   console.log('in save progress progress',req.body.progress)
  // const { userId, courseId, progress } = req.body;
  // console.log('progrss',progress)
  // try {
  //   await UserCourse.updateOne(
  //     { user: userId, course: courseId },
  //     {
  //       $set: { 
  //         progress: progress 
  //       },
  //     },
  //     { upsert: true } // Creates the document if it doesn't exist
  //   );
  //   console.log('Progress saved successfully');
  //   return res.status(200).json({ message: 'Progress Saved Successfully', success: true});
   

  // } catch (error) {
  //   console.error('Error updating lecture progress:', error);
  // }
  const { userId, courseId, progress } = req.body;

  try {
    let totalTimePlayed = 0;
    let totalSectionDuration = 0;

    // Calculate total time played and total section duration from the progress object
    for (const sectionKey in progress) {
      if (progress.hasOwnProperty(sectionKey)) {
        const section = progress[sectionKey];

        // Add this section's duration to the total
        const sectionDuration = parseInt(section.sectionDuration, 10) || 0;
        totalSectionDuration += sectionDuration;

        // Sum up time played for all lectures in this section
        const sectionTimePlayed = section.lectures.reduce((sum, lecture) => {
          return sum + (lecture.timePlayed || 0);
        }, 0);

        totalTimePlayed += sectionTimePlayed;
      }
    }

    // Calculate overall progress as a percentage
    const overallProgress = totalSectionDuration
      ? (totalTimePlayed / totalSectionDuration) * 100
      : 0;
    console.log('overallProgress',overallProgress)
    // Prepare the data to be saved, including overallProgress
    const progressToSave = {
      progress: progress,
      overallProgress: overallProgress.toFixed(2), // Save as a percentage with two decimal points
    };
    console.log('progressToSave',progressToSave)
    // Update or insert the progress data into the database
    await UserCourse.updateOne(
      { user: userId, course: courseId },
      { $set: progressToSave },
      { upsert: true } // Creates the document if it doesn't exist
    );

    console.log('Progress saved successfully with overall progress:', overallProgress);
    return res.status(200).json({ 
      message: 'Progress Saved Successfully', 
      success: true, 
      overallProgress: overallProgress.toFixed(2) 
    });

  } catch (error) {
    console.error('Error updating lecture progress:', error);
    return res.status(500).json({ message: 'Error saving progress', success: false });
  }
});

router.post('/purchaseCourse', authenticateToken, createPayment, async (req, res) => {
 
  console.log('in purchase course',req.body)
  const { payment } = req;
  const courseIds = req.body.course_ids;
  let totalPrice = 0;
  const courseDetails = await Course.find({ course_id: { $in: courseIds } });
  
  console.log('courseDetails',courseDetails)
 
  courseDetails.forEach(course => {
    totalPrice += course.price;
  });
  const approvalUrl = payment.links.find(link => link.rel === 'approval_url').href + '&amount=' + totalPrice;
  res.status(200).json({ approvalUrl });
});

router.get('/success', executePayment, async (req, res) => {
  try {
    const { courseId } = req.query;
    const userId = req.query.state; // Retrieve userId from the state parameter
    const courseIds = req.query.courseIds.split(','); // Get course IDs as an array
    console.log('userid in success',userId)
    if (!userId || userId===undefined) {
      return res.status(404).json({ error: 'User not found' });
    }  
    for (const courseId of courseIds) {
        const course = await Course.findOne({ course_id: courseId });
        if (course) {
          const newUserCourse = new UserCourse({
            user: userId,
            course: course._id,
            purchaseDate: new Date(),
            progress: new Map(), // Initialize progress
            overallProgress: 0,
          });
          console.log('newUserCourse:', newUserCourse);
          await newUserCourse.save(); // Save each course purchase
        }
      }
    
    return  res.redirect(`${ process.env.FRONTEND_URL}/mycourse?message=Course Successfully Purchased`);

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

router.get('/cancel', (req, res) => {
  res.status(200).json({ message: 'Payment cancelled' });
});

router.get("/login/success",(req,res)=>{
  if(req.user){
    res.status(200).json({
      error:false,
      message: "Successfully logged in",
      user:req.user
    })
  }else{
    res.status(403).json({error :true,message:"Not Authorized"})
  }
})
router.get("/login/failed",(req,res)=>{
  res.status(401).json({
    error:true,
    message:"Log in failure"

  })
})


// router.get('/google', passport.authenticate('google',{ successRedirect : 'http://localhost:3000/', failureRedirect:"/login/failed",}));

// router.get('/google/callback', passport.authenticate('google', {successRedirect : 'http://localhost:3000/',failureRedirect: "/login/failed" }),
//     (req, res) => { 

//       const user = req.user;

//       const token = generateToken(user._id);

//       res.status(200).json({ message: 'Sign-in successful', token });
//     }
//   );

  
module.exports = router;