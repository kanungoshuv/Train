const Course = require('../models/course'); // Adjust the path to where your Course model is located
const Messages = require('../config/Messages')
const PurchasedCourse = require('../models/userCourse')
async function findAllCourse() {
    try {
        const courses = await Course.find({});
        if (!courses) {
            throw new Error(Messages.serverMessage.courseNotFound);
        }
        return courses;
    } catch (error) {
       
        throw error;
    }
}

async function findAllCoursesPurchased(userId){
    try{
       
        const purchasedCourse = await PurchasedCourse.find({user:userId})
        return purchasedCourse;
    }catch(error){ 
        throw error
    }
}

async function findOneCourse(courseId) {
    try {
        const course = await Course.findOne({ _id: courseId });
        if (!course) {
            throw new Error(Messages.serverMessage.courseNotFound);
        }
        console.log(course);
        return course;
    } catch (error) {
        console.error(Messages.serverMessage.errorFetchingCourse, error);
        throw error;
    }
}

module.exports = { findOneCourse,
                    findAllCourse,
                    findAllCoursesPurchased
                };