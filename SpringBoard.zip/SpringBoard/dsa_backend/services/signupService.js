const User = require('../models/user'); // Adjust the path to where your Course model is located
const Messages = require('../config/Messages')
const EmailService= require('./EmailService')

async function registration(registrationData) {
  try {
    

   console.log('UserService.registration');

    // Check if User is active and verified
    const activeUser = await User.findActiveByCriteria({ email: registrationData.email, isVerified: true });
    if (activeUser) {
      console.log('activeUser....................', activeUser);
      //return callback('Already Present');
      
      return ({userPresent:'Already Present'});
    }

    // Check if user exists by criteria
    const existingUser = await User.findByCriteria({ email: registrationData.email });
    console.log('existing User ......................... dcefce 4564.............',existingUser)
    if (existingUser) {
      console.log('existingUser..................&%^%', existingUser);
      console.log('User already present.');
      return ({userPresent:'Already Present'});
      //return callback('Already Present');
    }

    // Create a new User
   //delete registrationData.confirmPassword;
   // registrationData.isVerified=false;
   let newUser;
   if(registrationData.isVerified ===true){
    newUser = await User.create(registrationData);
   }else{
     newUser = await User.create(registrationData);
      await EmailService.confirmAccountEmailToUser(newUser);
   }
   

    return  newUser;

  } catch (err) {
    console.log(`UserService.registration error: ${err}`);
    return err;
  }
}




module.exports = { registration,
                   
                };