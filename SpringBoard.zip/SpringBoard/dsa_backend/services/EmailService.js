// const User = require('../models/user'); // Adjust the path to where your Course model is located
// const Messages = require('../config/Messages')

// // const path = require('path');

// // const templatesDir = path.join(__dirname, '', 'templates');

// // const EmailTemplate = require('email-templates').EmailTemplate;

// // const nodemailer = require('nodemailer');

// // const noreplyEmail = 'miti8797@gmail.com';
// const path = require('path');
// const nodemailer = require('nodemailer');
// const Email = require('email-templates');

// const templatesDir = path.join(__dirname, 'templates');

// const noreplyEmail = 'miti8797@gmail.com';
// const noreplyEmailPass='Mitishah@1997'
// async function confirmAccountEmailToUser(user) {
//     console.log('templatesDir',templatesDir)
//     const template = new Email(path.join(templatesDir, 'confirmAccount-email'));
   
//     const transport = nodemailer.createTransport({
//       service: 'Gmail',
//       auth: {
//         user: noreplyEmail,
//         pass: noreplyEmailPass,
//       },
//     });
  
//     const locals = {
//       name: `${user.firstName} ${user.lastName}`,
//       id: user.id,
//       fullProjectName: 'DSA',
//       shortProjectName: 'DSA',
//     };
//     console.log('locals',locals)
//     try {
//         console.log('in try')
//       // Render the email template
//       const results = await template.render(locals);
//       console.log('results')
  
//       // Send the email
//       const mailOptions = {
//         from: 'miti8797@gmail.com',
//         to: user.email,
//         subject: 'Youre set up on',
//         html: results.html,
//         // attachments: [{
//         //   filename: '',
//         //   path: '',
//         //   cid: 'DSA-logo', // same cid value as in the html img src
//         // }],
//         text: results.text,
//       };
//     console.log('mail options',mailOptions)
//       const responseStatus = await transport.sendMail(mailOptions);
//       console.log('responseStatus',responseStatus);
//     } catch (err) {
//       console.log(`EmailService.confirmAccountEmailUser error: ${err}`);
//     }
//   }
  




// module.exports = { confirmAccountEmailToUser,
                   
//                 };

const path = require('path');
const nodemailer = require('nodemailer');
const Email = require('email-templates');
const User = require('../models/user'); // Adjust the path to where your Course model is located
const Messages = require('../config/Messages');

const templatesDir = path.join(__dirname, 'templates');

const noreplyEmail = 'miti8797@gmail.com';
const noreplyEmailPass = 'antc rymf swzk gwco';

async function confirmAccountEmailToUser(user) {
  console.log('templatesDir', templatesDir);

  const transport = nodemailer.createTransport({
    service: 'Gmail',
    auth: {
      user: noreplyEmail,
      pass: noreplyEmailPass,
    },
  });

  const email = new Email({
    message: {
      from: noreplyEmail,
    },
    transport: transport,
    views: {
      root: templatesDir,
      options: {
        extension: 'ejs', // Assuming you are using Handlebars templates
      },
    },
    send: true,
    preview: false,
  });

  const locals = {
    name: `${user.firstName} ${user.lastName}`,
    id: user.id,
    fullProjectName: 'DSA',
    shortProjectName: 'DSA',
  };
  console.log('locals', locals);

  try {
    console.log('in try');
    await email.send({
      template: 'confirmAccount-email', // This should match your template name without the file extension
      message: {
        to: user.email,
        subject: `Confirm Your Account on ${locals.fullProjectName}`,
        attachments: [
          {
            filename: 'sbshortlogo.png',
            path: path.join(__dirname, 'templates/assets/sbshortlogo.png'),
            cid: 'DSA-logo',
          },
        ],
      },
      locals: locals,
    });
    console.log('Email sent successfully');
  } catch (err) {
    console.log(`EmailService.confirmAccountEmailUser error: ${err}`);
  }
}

module.exports = { confirmAccountEmailToUser };
