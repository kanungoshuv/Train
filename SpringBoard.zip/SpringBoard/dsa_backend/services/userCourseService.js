const Course = require('../models/userCourse'); // Adjust the path to where your Course model is located
const Messages = require('../config/Messages')
const AllCourses = require('../models/course')

async function findMyCourseById(id) {
    try {
        const courses = await Course.find({ user: id }).lean();
        if (!courses || courses.length === 0) {
            return courses
        }
        const fetchCourses = await Promise.all(courses.map(async course => {
            const myCourses = await AllCourses.findOne({ _id: course.course }).lean();
                return { ...course, courseDetails: myCourses };
        }));
        return fetchCourses;
    } catch (error) {
       
        throw error;
    }
}

module.exports = { findMyCourseById,  
                };