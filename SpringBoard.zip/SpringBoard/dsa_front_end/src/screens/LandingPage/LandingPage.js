import { Fragment ,useState,useEffect} from "react";
import {
  Card,
  Grid,
  styled,
  useTheme,
  CardActions,
  CardContent,
  CardMedia,
  Button,
  Typography,
  Box
} from "@mui/material";
import { useSelector,useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { CourseListFunction,CourseAllListFunction } from '../../Redux/slices/CourseSlice/CourseAPI';
import MemoryIcon from "@mui/icons-material/Memory";

const ContentBox = styled("div")(({ theme }) => ({
  margin: "85px",
  [theme.breakpoints.down("sm")]: { margin: "16px" }
}));

const Title = styled("span")(() => ({
  fontSize: "1rem",
  fontWeight: "500",
  marginRight: ".5rem",
  textTransform: "capitalize"
}));

const SubTitle = styled("span")(({ theme }) => ({
  fontSize: "0.875rem",
  color: theme.palette.text.secondary
}));

const H4 = styled("h4")(({ theme }) => ({
  fontSize: "1rem",
  fontWeight: "500",
  marginBottom: "16px",
  textTransform: "capitalize",
  color: theme.palette.text.secondary
}));

  const LandingPage = ({setNavData,setCartData}) => {
  const { palette } = useTheme();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  let purchased_course_data = useSelector(state => state.Course?.purchased_course_data);
  let course_data = useSelector(state => state.Course?.course_data);
  const [courseData,setCourseData]=useState()
  const [userPresent,setUserPresent]=useState(false);
  const [open, setOpen] = useState(false);
  const [openRemove,setOpenRemove]= useState(false);
  const [addedToCart,setAddedToCart] = useState([]);
  const [cart, setCart] = useState([]);
  const [cartDataFromLocal, setCartDataFromLocal] = useState([]);
  const [cartLength, setCartLength] = useState(0);
  let heading = "SPRINGBOARD ONLINE COURSES"
  let jwt_token = localStorage.getItem('jwt_token_springboard')

  useEffect(() => {
   
    let cart_data= localStorage.getItem('cart_data');
  
    let cart_data_length= localStorage.getItem('cart_data_length');
    if(cart_data_length>0){
      setCartDataFromLocal(cart_data)
      setCartLength(cart_data_length)
      setCart(JSON.parse(cart_data));
      setCartData(JSON.parse(cart_data)); 
    }
    const fetchData = async () => {
      if (!courseData || courseData.length === 0) {
        const response = await dispatch(CourseListFunction());
       
        setCourseData(response.payload.data.Course_list);
      }
    };
    const fetchAllData = async () => {
      
        const response = await dispatch(CourseAllListFunction());
        setCourseData(response.payload.data.Course_list);
      
    };
    if (!jwt_token && course_data &&  !courseData) {
      fetchAllData();
     // window.location.reload()
    }else 
    if(jwt_token==null && courseData==undefined){
     
      navigate('/signin')
    }else
    if (jwt_token && course_data && !courseData) {
      fetchData();
    }  
  }, [dispatch,navigate]);




const handleClose = (event, reason) => {
  if (reason === 'clickaway') {
    return;
  }
  setOpen(false);
};
const handleCartToggle = (course) => {

  if (cart.some(item => item.course_id === course.course_id)) { 
    const updatedCart = cart.filter(item => item.course_id !== course.course_id);

    setCart(updatedCart);
    setCartData(updatedCart); 
    setOpenRemove(true);
    setNavData(updatedCart.length); 

    localStorage.setItem('cart_data', JSON.stringify(updatedCart));
    localStorage.setItem('cart_data_length', updatedCart.length);
  } else {
    const updatedCart = [...cart, course];

    setCart(updatedCart);
    setCartData(updatedCart); 
    setOpen(true);
    setNavData(updatedCart.length); 

    localStorage.setItem('cart_data', JSON.stringify(updatedCart));
    localStorage.setItem('cart_data_length', updatedCart.length);
  }
};
  return (
    <Fragment>
       <ContentBox>
      <h1 style={{ textAlign: "center" }}>{heading}</h1>

      <Grid container spacing={6}>
        {/* <Grid item lg={8} md={8} sm={12} xs={12}>
            <StatCards />
          </Grid> */}
           {  jwt_token == null && courseData && courseData.map((course, index) => (
        <Grid item lg={4} md={4} sm={12} xs={12}>
          <Card sx={{ border: "3px solid black", borderRadius: "0px", padding: "16px" }}>
            <CardMedia
              sx={{ height: 200 }}
              image={`/images/${course.course_picture}`}
              title="green iguana"
            />
            <CardContent>
              <div style={{ display: "flex" }}>
                {" "}
                <MemoryIcon fontSize="large" />
                <Typography gutterBottom variant="h5" component="div">
                <b>{course.course_name.toUpperCase()}</b> 
                </Typography>
              </div>
              <Typography variant="body2" sx={{ color: "text.secondary" }}>
              {course.course_description} Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                unknown printer took a galley of type and scrambled it to make a type specimen book.
                It has survived not only five centuries, but also the leap into electronic.
              </Typography>
              <br></br>
              <Typography >
                <b>- Dr. Steven Lindo, Chairman and CEO</b>
              </Typography>
            </CardContent>
            
            <CardActions>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
              <Typography sx={{ ml: 1,fontSize: '1.1rem',color:'dimgrey' }}>${course.price}</Typography>
              <Button 
                color="success" 
                variant="outlined" 
                size="small" 
                onClick={() => handleCartToggle(course)}
              >
                {cart.some(item => item.course_id === course.course_id) ? 'Remove From Cart' : 'Add to Cart'}
              </Button>
            </Box>
          </CardActions>

          </Card>
        </Grid>
  ))}
  {jwt_token  && courseData && courseData.coursesWithPurchasedDetails && courseData.coursesWithPurchasedDetails
      .map((course, index) => (
        <Grid item lg={4} md={4} sm={12} xs={12}>
          <Card sx={{ border: "3px solid black", borderRadius: "0px", padding: "16px" }}>
            <CardMedia sx={{ height: 200 }} image={`/images/${course.course_picture}`}title="green iguana" />
            <CardContent>
              <div style={{ display: "flex" }}>
                {" "}
                <MemoryIcon fontSize="large" />
                <Typography gutterBottom variant="h5" component="div">
                <b>{course.course_name.toUpperCase()}</b> 
                </Typography>
              </div>

              <Typography variant="body2" sx={{ color: "text.secondary" }}>
              {course.course_description} Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                unknown printer took a galley of type and scrambled it to make a type specimen book.
                It has survived not only five centuries, but also the leap into electronic.
              </Typography>
              <br></br>
              <Typography >
                <b>Dr. Steven Lindo, Chairman and CEO</b>
              </Typography>
            </CardContent>
            <CardActions sx={{ justifyContent: "right" }}>
              <Button color="success" variant="outlined" size="small">
              Start Course
              </Button>
            </CardActions>
          </Card>
        </Grid>
         ))}

{jwt_token  && courseData && courseData.coursesWithoutPurchasedDetails
      .map((course, index) => (
        <Grid item lg={4} md={4} sm={12} xs={12}>
           <Card sx={{ border: "3px solid black", borderRadius: "0px", padding: "16px" }}>
            <CardMedia
              sx={{ height: 200 }}
              image={`/images/${course.course_picture}`}
              title="green iguana"
            />
            <CardContent>
              <div style={{ display: "flex" }}>
                {" "}
                <MemoryIcon fontSize="large" />
                <Typography gutterBottom variant="h5" component="div">
                <b>{course.course_name.toUpperCase()}</b> 
                </Typography>
              </div>
              <Typography variant="body2" sx={{ color: "text.secondary" }}>
              {course.course_description} Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                Ipsum has been the industry's standard dummy text ever since the 1500s, when an
                unknown printer took a galley of type and scrambled it to make a type specimen book.
                It has survived not only five centuries, but also the leap into electronic.
              </Typography>
              <br></br>
              <Typography >
                <b>Dr. Steven Lindo, Chairman and CEO</b>
              </Typography>
            </CardContent>
            
            <CardActions>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
              <Typography sx={{ ml: 1,fontSize: '1.1rem',color:'dimgrey' }}>${course.price}</Typography>
              <Button 
                color="success" 
                variant="outlined" 
                size="small" 
                onClick={() => handleCartToggle(course)}
              >
                {/* {cartLength >0 && cartDataFromLocal.some(item => item.course_id === course.course_id) ? 'Remove From Cart' : 'Add to Cart'} */}
                {cart.some(item => item.course_id === course.course_id) ? 'Remove From Cart' : 'Add to Cart'}
              </Button>
            </Box>
          </CardActions>

          </Card>
        </Grid>
         ))}

      </Grid>
      </ContentBox>
    </Fragment>
  );
}
export default LandingPage;