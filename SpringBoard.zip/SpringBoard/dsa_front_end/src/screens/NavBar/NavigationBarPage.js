import { useEffect,useState } from 'react';
import { 
    Grid,
    AppBar,
    Toolbar,
    Typography,
    Box,
    IconButton ,
    Badge,
    Menu, MenuItem
} from '@mui/material';
import { AccountCircle } from '@mui/icons-material';
import CourseImage from '../../assets/DataStructure.jpeg'
import AIMLImage from '../../assets/AIMLPicture.jpeg'
import CyberSecurityImage from '../../assets/CybersecurityImage.webp'
import DatabaseImage from '../../assets/DatabaseImage.jpeg'
import DataScienceImage from '../../assets/DataScienceImage.png'
import SpringBoardIncubatorsLogo from '../../assets/SpringBoardIncubatorsLogo.png'
import { Button } from 'semantic-ui-react'
import { Link } from 'react-router-dom';
import { useSelector,useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { CourseListFunction } from '../../Redux/slices/CourseSlice/CourseAPI';
import  SpringBoardLogo  from '../../assets/SpringBoardIncubatorsLogo.png';
import SpringBoardLogo1 from '../../assets/sb_logo.png';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useLocation } from 'react-router-dom';
import { logoutFunction } from '../../Redux/slices/UserSlice/UserAPI';

const Navbar = {
 backgroundColor: '#9BEDCC'   
}

const LoginLogoStyle = {
  height: '2.5rem',
  width: '2.5rem'  
}

const MyCourseButton = {
  paddingRight: '2rem'  
}


const MainContainer = {
  width: '100%',
  height: '100%',
  display: 'flex', 
  margin: '0 10% 0 10%',
  flexDirection: 'row',
  justifyContent: 'center', 
  marginTop: '5%',
}

const HeaderContainer = {
  display: 'flex', 
  flexDirection: 'row',
  justifyContent: 'center', 
  marginTop: '5%'
}

const HeadingStyle = {
  fontSize: '2rem'
}

const SpringBoardIncubatorsLogoStyle = {
  width: '9rem',
  height: '2rem',
}


const CourseContainer = {
 minwidth: '10rem',
 boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
 borderRadius: '1.4rem',  
 marginLeft: '2rem'
}

const LastCourseContainer = {
  minwidth: '10rem',
  // boxShadow: '0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)',
  borderRadius: '1.4rem',  
  marginLeft: '2rem'
 }

const CourseOuterContainer = {
  display: 'flex', 
  flexDirection: 'row',
  justifyContent: 'center', 
}

const CourseImageStyle = {
  maxWidth: '30%',
  height: '3rem'
}


const LastSectionContainer = {
  display: 'flex', 
  flexDirection: 'row',
  justifyContent: 'space-between', 
  padding: '2% 3% 4% 3%'
}

const CourseCompleteTextStyle = {
  fontSize: '2rem'
}

const CourseHeaderStyle = {
  fontSize: '1.18rem',
  margin: '5% 3% 0 3%'
}


  const NavigationBarPage = ({navData,cartData}) => {
   
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  let purchased_course_data = useSelector(state => state.Course?.purchased_course_data);
  let course_data = useSelector(state => state.Course?.course_data);
  const [userPresent,setUserPresent] =useState(false)
    const [myCoursePath,setMyCoursePath] = useState(false)
  useEffect(() => {
  
    if(location.pathname ==='/mycourse'){
     
      setMyCoursePath(true)
    }
    let jwt_token = localStorage.getItem('jwt_token_springboard')
    
   
    if(jwt_token == null){
        setUserPresent(false)
    }else if(jwt_token){
        setUserPresent(true)
    }
    
   },[]) 
  const handleClickOfSignin =()=>{
    navigate('/signin')
  }
  const handleClickOfImage =()=>{
    navigate('/')
  }
  const handleClickOfShoppingCart = (cartData) => {
   
    navigate('/cart', { state: { cartData } })
  }
  const handleClickOfMyCourse =()=>{

    navigate('/mycourse')
  }
  const handleClickOfIcon = (event) => {
    setAnchorEl(event.currentTarget);
  };


  const handleCloseOfLogoutIcon = async () => {
    setAnchorEl(null);
   
     const response = await dispatch(logoutFunction());
   

     if(response.payload.data.status ==="200"){
      localStorage.clear();
      sessionStorage.clear();
      navigate('/signin')
     }
  };
  const handleCloseOfIcon = async () =>{
    setAnchorEl(null);
  }
 return (
  <>  
  
    <AppBar position="static" sx={Navbar}>
      <Toolbar>
        <Typography style={{color:'black'}} variant="h6" sx={{ flexGrow: 1}}>
            <img onClick={handleClickOfImage} src={SpringBoardLogo} style={{width:'15%'}}/> 
        </Typography>
      
        <Typography style={{color:'black'}} variant="body1" sx={MyCourseButton}>
            {userPresent=== false || myCoursePath=== true? '':  <Button onClick ={handleClickOfMyCourse}sx={{  width: '120%',textTransform: 'none' }} style={{backgroundColor:'azure',color:'black'}}>My Course</Button> } 
        </Typography>

        <div style={{marginRight:'2%'}}>
          {
            navData >0 &&  <Badge sx={{
              '& .MuiBadge-badge': {
                backgroundColor: 'black',  // Badge background color
                color: 'white',            // Badge text color
              },
            }} badgeContent={navData} color="primary">
            <ShoppingCartIcon onClick={() => handleClickOfShoppingCart(cartData)} style={{color:'black', marginRight:'1%'}}/>
            </Badge>
          }
       {
        (navData ==0 || navData == undefined  )&&  
        <ShoppingCartIcon onClick={() => handleClickOfShoppingCart(cartData)} style={{color:'black', marginRight:'1%'}}/>
       
       }
       </div>
        
        {
        userPresent ===false ?   
        
       
        <Button   
        size="small" onClick={handleClickOfSignin}style={{backgroundColor:'azure',color:'black'}}>Signin</Button>
        :

       [ <IconButton onClick={handleClickOfIcon}>
          <AccountCircle sx={LoginLogoStyle}/> 
        </IconButton>,
         <Menu
         anchorEl={anchorEl}
         open={open}
         onClose={handleCloseOfIcon}
         PaperProps={{
           elevation: 3,
           style: {
             width: '20ch',
           },
         }}
         >
         <MenuItem onClick={handleCloseOfIcon}>Profile</MenuItem>
         <MenuItem onClick={handleCloseOfIcon}>My Account</MenuItem>
         <MenuItem onClick={handleCloseOfLogoutIcon}>Logout</MenuItem>
         </Menu>]

       
        }


     
      </Toolbar>
    </AppBar>    
   
   
  </>  
 )   
}

 export default NavigationBarPage;