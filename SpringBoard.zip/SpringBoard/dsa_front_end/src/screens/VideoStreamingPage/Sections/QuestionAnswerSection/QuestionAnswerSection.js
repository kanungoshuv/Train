import { 
    Typography
} from '@mui/material';


const QuestionAnswerSection = () => {

 return (
   <>
    <Typography>Question Answer Section</Typography>
   </> 
 )
 
}

export default QuestionAnswerSection;