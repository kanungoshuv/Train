import { 
    Typography,
    Grid,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    AccordionActions,
    Button
} from '@mui/material';
import  ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const CourseContentInnerContainer = {

}

const CourseContentOuterContainer = {
  display: 'flex', 
  flexDirection: 'row',
  justifyContent: 'center', 
  width: '100%'
}

const CourseContentSection = () => {

 return (
   <>
    <Grid container sx={CourseContentOuterContainer} xs={12} sm={12} md={12}>
     <Grid item sx={CourseContentInnerContainer} xs={12} sm={12} md={12}>
      <Accordion sx={{ width: '100%' }}>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1-content"
          id="panel1-header"
        >
          Introduction
        </AccordionSummary>
        <AccordionDetails>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
          malesuada lacus ex, sit amet blandit leo lobortis eget.
        </AccordionDetails>
      </Accordion>     
     </Grid>      
    </Grid>
   </> 
 )
 
}

export default CourseContentSection;