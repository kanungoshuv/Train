import { 
    Typography
} from '@mui/material';


const AnnouncementSection = () => {

 return (
   <>
    <Typography>Announcement Section</Typography>
   </> 
 )
 
}

export default AnnouncementSection;