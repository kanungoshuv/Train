import { memo, useRef,useEffect,useState ,useContext} from "react";
import { Link } from "react-router-dom";
import {
  Box,
  styled,
  useTheme,
  MenuItem,
  IconButton,
  useMediaQuery,
  Button,
  Tooltip,
  Badge,
  Popover,
  Typography,
  List, ListItem, ListItemText, CssBaseline,
  Grid,
  Divider
} from "@mui/material";
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import PsychologyIcon from '@mui/icons-material/Psychology';
import { CourseListFunction,CourseAllListFunction } from '../../Redux/slices/CourseSlice/CourseAPI';

import { useSelector,useDispatch } from 'react-redux';
import { logoutFunction } from '../../Redux/slices/UserSlice/UserAPI';
import { useNavigate,useLocation } from 'react-router-dom';
import { CartContext } from '../ShoppingCart/CartContext';
import {clearState} from '../../Redux/slices/CourseSlice/CourseSlice'
// STYLED COMPONENTS
const StyledIconButton = styled(IconButton)(({ theme }) => ({
  color: theme.palette.text.primary
}));
const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  boxShadow: 24,
  p: 4,
};
const TopbarRootFirstHeader = styled("div")({
    position:'fixed',
  top: 0,
  zIndex: 96,
  height: 40,
  width:"100%",
  //boxShadow: themeShadows[8],
  transition: "all 0.3s ease",
  whiteSpace: "nowrap",
  overflow: "hidden",
  
});

const TopbarContainerFirstHeader = styled(Box)(({ theme }) => ({
  padding: "5px",
  paddingLeft: 18,
  paddingRight: 20,
  height: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  background: "#275317",
  // backgroundImage:'url("/TopContainer.png")',
  [theme.breakpoints.down("sm")]: { paddingLeft: 16, paddingRight: 16 },
  [theme.breakpoints.down("xs")]: { paddingLeft: 14, paddingRight: 16 }
}));

const TopbarRootMiddleHeader = styled("div")({
  position:'fixed',
  top: 0,
  zIndex: 96,
  width:"100%",
  height: 64,
 // boxShadow: themeShadows[8],
  transition: "all 0.3s ease",
  whiteSpace: "nowrap",
  overflow: "hidden",
});

const TopbarContainerMiddleHeader = styled(Box)(({ theme }) => ({
  padding: "8px",
  paddingLeft: 18,
  paddingRight: 20,
  height: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  backgroundImage:   'url("/MiddleContainer.png")',
  // background: "#3B7D23",
  [theme.breakpoints.down("sm")]: { paddingLeft: 16, paddingRight: 16 },
  [theme.breakpoints.down("xs")]: { paddingLeft: 14, paddingRight: 16 }
}));

const TopbarRoot = styled("div")({
  position:'fixed',
  top: 0,
  zIndex: 96,
  width:"100%",
  height: 40,
//  boxShadow: themeShadows[8],
  transition: "all 0.3s ease",
  whiteSpace: "nowrap",
  overflow: "hidden",
});

const TopbarContainer = styled(Box)(({ theme }) => ({
  padding: "8px",
  paddingLeft: 18,
  paddingRight: 20,
  height: "100%",
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  // background: "#275317",
  backgroundImage:   'url("/Gradient.png")',
  [theme.breakpoints.down("sm")]: { paddingLeft: 16, paddingRight: 16 },
  [theme.breakpoints.down("xs")]: { paddingLeft: 14, paddingRight: 16 }
}));

const UserMenu = styled(Box)({
  padding: 4,
  display: "flex",
  borderRadius: 24,
  cursor: "pointer",
  alignItems: "center",
  "& span": { margin: "0 8px" }
});

const StyledItem = styled(MenuItem)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  minWidth: 185,
  "& a": {
    width: "100%",
    display: "flex",
    alignItems: "center",
    textDecoration: "none"
  },
  "& span": { marginRight: "10px", color: theme.palette.text.primary }
}));

const IconBox = styled("div")(({ theme }) => ({
  display: "inherit",
  [theme.breakpoints.down("md")]: { display: "none !important" }
}));

const Layout1Topbar = ({ coursesRef,curriculumRef,navData,cartData,jobTrainingRef}) => {
  const theme = useTheme();
  const navigate = useNavigate();
  const isMdScreen = useMediaQuery(theme.breakpoints.down("md"));
  const dispatch = useDispatch();
  const location = useLocation();
  // const open = Boolean(anchorEl);
  const [ cartLength,setCartLength] =useState(0)
  let purchased_course_data = useSelector(state => state.Course?.purchased_course_data);
  let course_data = useSelector(state => state.Course?.course_data);
  const { cartItems } = useContext(CartContext);
  const [anchorEl, setAnchorEl] = useState(null);
  const [courseData,setCourseData]=useState()


  const [userPresent,setUserPresent] =useState(false)
    const [myCoursePath,setMyCoursePath] = useState(false)
    const categories = [
      {
        title: 'Software Development',
        items: ['Databases', 'Game Development', 'Mobile Development', 'Programming Languages', 'Web Development'],
      },
      {
        title: 'Security',
        items: [
          'Certifications',
          'Governance, Risk & Compliance',
          'Security Architecture & Engineering',
          'Security Operations',
          'Security Testing',
        ],
      },
      {
        title: 'Data & Machine Learning',
        items: ['Big Data', 'Business Intelligence', 'Data Visualization', 'Databases', 'Languages & Libraries', 'Machine Learning'],
      },
      {
        title: 'Cloud',
        items: ['Cloud Architecture & Design', 'Cloud Platforms', 'Salesforce CRM'],
      },
      {
        title: 'IT Ops',
        items: ['Client Operating Systems', 'Collaboration Platforms', 'Configuration Management', 'Containers', 'IT Automation'],
      },
      {
        title: 'Business Professional',
        items: ['Office Applications', 'Security Awareness'],
      },
    ];
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const open = Boolean(anchorEl);
  const id = open ? 'simple-popover' : undefined;
  useEffect(() => {
  
    if(location.pathname ==='/mycourse'){
     
      setMyCoursePath(true)
    }
    let jwt_token = localStorage.getItem('jwt_token_springboard')
    let cart_data_length =localStorage.getItem('cart_data_length');
    
    if(cart_data_length){
      setCartLength(cart_data_length)
    }
   
    fetchAllData();
    if(jwt_token == null){
        setUserPresent(false)
    }else if(jwt_token){
        setUserPresent(true)
    }
    
    
   },[cartLength]) 

   const fetchAllData = async () => {
      
    const response = await dispatch(CourseAllListFunction());
    console.log('response in fetch all data layout',response)
    setCourseData(response.payload.data.Course_list);
  
};
console.log('response in fetch all data layout outside',courseData)
  const handleClickOfSignin =()=>{
    navigate('/signin')
  }
  const handleClickOfImage =()=>{
    navigate('/')
  }
  const handleClickOfShoppingCart = (cartData) => {

    navigate('/cart', { state: { cartData } })
  }
  const handleClickOfMyCourse =()=>{

    navigate('/mycourse')
  }
  const handleClickOfIcon = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClickOfElearning = async () =>{
    navigate('/')
  }
  const handleCloseOfLogoutIcon = async () => {
    setAnchorEl(null);
   
    dispatch(clearState());    
     const response = await dispatch(logoutFunction());


     if(response.payload.data.status ==="200"){
      localStorage.clear();
      sessionStorage.clear();
      navigate('/signin')
     }
  };
  const handleCloseOfIcon = async () =>{
    setAnchorEl(null);
  }
  const handleScrollTo = (ref) => {
   
      if(ref === undefined){
        navigate('/')
      }else{
        ref.current.scrollIntoView({ behavior: "smooth" });
      }
  };
  const handleClickOfList = (courseDetails) => {
    setAnchorEl(null);
    console.log('course details in click of card media',courseDetails)
    navigate('/courseDetail',{state:{courseDetails}})
  };
  const capitalizeWords = (text) =>{
    return text
      .split(" ") 
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) 
      .join(" "); 
  }
  return (
    <>
      <TopbarRootFirstHeader sx={{ top: 0 }}>
        <TopbarContainerFirstHeader >
          <Box display="flex">
            <IconBox>
              <StyledIconButton>
                <b style={{ fontSize: "15px", color: "white" }}>School Districts</b>
              </StyledIconButton>

              <StyledIconButton>
                <b style={{ fontSize: "15px", color: "white" }}>University C/STEP</b>
              </StyledIconButton>

              <StyledIconButton>
                <b style={{ fontSize: "15px", color: "white" }}>Community &nbsp;(CBOs)</b>
              </StyledIconButton>
            </IconBox>
          </Box>
        </TopbarContainerFirstHeader>
      </TopbarRootFirstHeader>
      <TopbarRootMiddleHeader sx={{ top: "40px" }}>
        <TopbarContainerMiddleHeader>
          <Box display="flex">
            <IconBox>
              <StyledIconButton onClick={handleClickOfElearning}>
                <img
                  style={{ width: "30px", height: "30px" ,marginRight:'9px'}}
                  src="/SBlogowhitenew.png"
                ></img>

                <b style={{ fontSize: "17px", color: "white" }}> eLearning</b>
              </StyledIconButton>
            </IconBox>
          </Box>
          <Box display="flex">
            <IconBox>
              <StyledIconButton onClick={() => handleScrollTo(coursesRef)}>
                <b style={{ fontSize: "17px", color: "white" }}>All Courses</b>
              </StyledIconButton>

              <StyledIconButton>
                <b
                  style={{ fontSize: "17px", color: "white" }}
                  onClick={() => handleScrollTo(jobTrainingRef)}
                >
                  Job Training
                </b>
              </StyledIconButton>
              <StyledIconButton>
                <b
                  style={{ fontSize: "17px", color: "white" }}
                    onClick={() => handleScrollTo(curriculumRef)}
                >
                  Curriculum
                </b>
              </StyledIconButton>
            </IconBox>
          </Box>
          {/* <Box>
            <IconBox>
              <Button  sx={{
               
               // backgroundColor: "gainsboro",
                borderColor: "white",
                color: "white",
                // "&:hover": {
                //   backgroundColor: "#76c76b"
                // }
              }} variant="outlined">Business Consulting</Button>
            </IconBox>
          </Box> */}
          <Box display="flex">
            <img
              style={{  height: "46px" }}
              src="WhiteSpringBoardLogo.png"
            ></img>
          </Box>
        </TopbarContainerMiddleHeader>
      </TopbarRootMiddleHeader>
      <TopbarRoot sx={{ top: "100px" }}>
        <TopbarContainer>
          <Box display="flex">
            <IconBox></IconBox>
          </Box>
          <Box display="flex" alignItems="center">
            <IconBox>
           
            <Tooltip title="View Cart">
            <StyledIconButton style={{marginRight:'4px'}}>
             <Badge sx={{
              '& .MuiBadge-badge': {
                backgroundColor: 'white',  
                color: 'black',            
              },
            }} badgeContent={cartItems.length}>
           <ShoppingCartIcon  onClick={() => handleClickOfShoppingCart(cartData)} style={{color:'white'}}/>
            </Badge>
          
      
            
            </StyledIconButton>
            </Tooltip>
            {userPresent=== false || myCoursePath=== true? '': 
            <StyledIconButton onClick ={handleClickOfMyCourse}>
                <b style={{ fontSize: "15px", color: "white" }}>My Course</b>
              </StyledIconButton>}
              <div>
            <StyledIconButton onClick={handleClick} style={{ display: 'flex', alignItems: 'center' }}>
            <b style={{ fontSize: "15px", color: "white", lineHeight: '1.5' }}>Products</b>
            <span style={{ color: 'white', fontSize: "15px", display: 'flex', alignItems: 'center' }}>
              {open ? <KeyboardArrowUpIcon style={{ verticalAlign: 'middle' }} /> : <KeyboardArrowDownIcon style={{ verticalAlign: 'middle' }} />}
            </span>
          </StyledIconButton>
              </div>
              <StyledIconButton>
                <b style={{ fontSize: "15px", color: "white" }}>Contact Us</b>
              </StyledIconButton>
              {
              userPresent ===false ?   
        
              <StyledIconButton onClick={handleClickOfSignin}>
                <b style={{ fontSize: "15px", color: "white" }}>Sign In</b>
              </StyledIconButton>
              : <StyledIconButton onClick={handleCloseOfLogoutIcon}>
              <b style={{ fontSize: "15px", color: "white" }}>Logout</b>
            </StyledIconButton>}
            </IconBox>
          </Box>
        </TopbarContainer>
      </TopbarRoot>
      {open && (
        <Box
          sx={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100vw',
            height: '100vh',
            backdropFilter: 'blur(8px)', 
            zIndex: 1,  
            backgroundColor: 'rgba(0, 0, 0, 0.5)', 
          }}
        />
      )}
     <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        transformOrigin={{
          vertical: 'top',
          horizontal: 'left',
        }}
        PaperProps={{
          style: {
            width: '1200px',
            padding: '16px',
            zIndex: 2,  
          },
        }}
      >
        <Box display="flex" justifyContent="space-around">
         
          <Grid container spacing={6}>
        <Grid item lg={4} md={4} sm={12} xs={12}>
        <div style={{ display: "flex" }}>
                {" "}
                <PsychologyIcon fontSize="large" />
                <Typography gutterBottom variant="h6" component="div">
                  <b>SOFTWARE ENGINEERING</b>
                </Typography>
              </div>
              <Divider />
              <List>
            {courseData && courseData
              .filter((course) => course.type === "All") 
              .map((course) => (
                <ListItem 
                  key={course.course_name} 
                  onClick={() => handleClickOfList(course)}
                  style={{ cursor: "pointer" }}
                >
                  <ListItemText primary={capitalizeWords(course.course_name)}  /> 
                </ListItem>
              ))}
          </List>
            
        </Grid>
        <Grid item lg={4} md={4} sm={12} xs={12}>
        <div style={{ display: "flex" }}>
                {" "}
                <PsychologyIcon fontSize="large" />
                <Typography gutterBottom variant="h6" component="div">
                  <b>JOB TRAINING</b>
                </Typography>
              </div>
              <Divider />
             
               <List>
            {courseData && courseData
              .filter((course) => course.type === "jobTraining") 
              .map((course) => (
                <ListItem 
                  key={course.course_name} 
                  onClick={() => handleClickOfList(course)}
                  style={{ cursor: "pointer" }}
                >
                  <ListItemText primary={capitalizeWords(course.course_name)} /> {/* Render course_name in lowercase */}
                </ListItem>
              ))}
          </List>
        </Grid>
        <Grid item lg={4} md={4} sm={12} xs={12}>
        <div style={{ display: "flex" }}>
                {" "}
                <PsychologyIcon fontSize="large" />
                <Typography gutterBottom variant="h6" component="div">
                  <b>CURRICULUM</b>
                </Typography>
              </div>
              <Divider />
              <List>
                <ListItem style={{ cursor: "pointer" }}><ListItemText primary="Lesson Plans" /></ListItem>
                <ListItem style={{ cursor: "pointer" }}><ListItemText primary="Instructor Resources" /></ListItem>
                <ListItem style={{ cursor: "pointer" }}><ListItemText primary="Teacing Observation" /></ListItem>
                {/* <ListItem><ListItemText primary="Programming Languages" /></ListItem>
                <ListItem><ListItemText primary="Web Development" /></ListItem> */}
              </List>
        </Grid>
      
      </Grid>
        </Box>
      </Popover>
    </>
  );
};

export default memo(Layout1Topbar);
